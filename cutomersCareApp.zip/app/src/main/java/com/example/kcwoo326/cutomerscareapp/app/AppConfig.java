package com.example.kcwoo326.cutomerscareapp.app;

/**
 * Created by KimJinWoo on 2016-08-04.
 */
public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://wlsdnghkd123.iptime.org:8080/pos_manager_login_api/poslogin.php";

    // Server user register url
    public static String URL_REGISTER = "http://wlsdnghkd123.iptime.org:8080/pos_manager_login_api/posregister.php";

    public static String URL_CCARETABLE = "http://wlsdnghkd123.iptime.org:8080/test.php";

    public static String URL_SETCCARETABLE = "http://wlsdnghkd123.iptime.org:8080/whetherthecallinsert.php";
}
